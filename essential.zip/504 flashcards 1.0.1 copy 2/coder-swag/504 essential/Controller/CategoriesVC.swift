
import UIKit

var category = 0

class CategoriesVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var selectedIndex = 0
    @IBOutlet weak var categoryTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        categoryTable.dataSource = self
        categoryTable.delegate = self
    }
    
    // These functions must be included when you include the TableView Delegates
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return DataService.instance.getLessonList().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell") as? CategoryCell {
                        
       
            let category = DataService.instance.getLessonList()[indexPath.row]
    
            cell.updateViews(for: category)
            return cell
        } else {
            return CategoryCell()
        }
    }
    
    // Function to change VC's
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
        category = DataService.instance.getLessonList()[indexPath.row]
        performSegue(withIdentifier: "ProductsVC", sender: category)

    }
    
    // Function to send data to new VC
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let productsVC = segue.destination as? ProductsVC {
            if segue.identifier == "ProductsVC" {
                let text = DataService.instance.getLessonList()[selectedIndex]
            productsVC.someText = "\(text)"
            productsVC.indexOfCategory = selectedIndex
            let barBtn = UIBarButtonItem()
            barBtn.title = ""
            navigationItem.backBarButtonItem = barBtn
            productsVC.initFlashCards(for: category)
            }
        }
    }

    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        typealias Animation = (UITableViewCell, IndexPath, UITableView) -> Void
        func makeMoveUpWithBounce(rowHeight: CGFloat, duration: TimeInterval, delayFactor: Double) -> Animation {
            return { cell, indexPath, tableView in
                cell.transform = CGAffineTransform(translationX: 0, y: rowHeight)

                UIView.animate(
                    withDuration: duration,
                    delay: delayFactor * Double(indexPath.row),
                    usingSpringWithDamping: 0.4,
                    initialSpringVelocity: 0.1,
                    options: [.curveEaseInOut],
                    animations: {
                        cell.transform = CGAffineTransform(translationX: 0, y: 0)
                })
            }
        }
        final class Animator {
            private var hasAnimatedAllCells = false
            private let animation: Animation

            init(animation: @escaping Animation) {
                self.animation = animation
            }

            func animate(cell: UITableViewCell, at indexPath: IndexPath, in tableView: UITableView) {
                guard !hasAnimatedAllCells else {
                    return
                }

                animation(cell, indexPath, tableView)

                hasAnimatedAllCells = tableView.isLastVisibleCell(at: indexPath)
            }
        }

        func makeMoveUpWithFade(rowHeight: CGFloat, duration: TimeInterval, delayFactor: Double) -> Animation {
            return { cell, indexPath, _ in
                cell.transform = CGAffineTransform(translationX: 0, y: rowHeight / 2)
                cell.alpha = 0

                UIView.animate(
                    withDuration: duration,
                    delay: delayFactor * Double(indexPath.row),
                    options: [.curveEaseInOut],
                    animations: {
                        cell.transform = CGAffineTransform(translationX: 0, y: 0)
                        cell.alpha = 1
                })
            }
        }
        let animation = makeMoveUpWithFade(rowHeight: cell.frame.height, duration: 0.5, delayFactor: 0)
        let animator = Animator(animation: animation)
            animator.animate(cell: cell, at: indexPath, in: tableView)

    }
}
extension UITableView {
    func isLastVisibleCell(at indexPath: IndexPath) -> Bool {
        guard let lastIndexPath = indexPathsForVisibleRows?.last else {
            return false
        }

        return lastIndexPath == indexPath
    }
}
