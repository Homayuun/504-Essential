//
//  CategoryCell.swift
//  parsingJson
//
//  Created by Homayun on 11/28/1400 AP.
//

import UIKit

class CategoryCell: UITableViewCell {

    @IBOutlet weak var categoryImage: UIImageView!
    @IBOutlet weak var categoryTitle: UILabel!
    @IBOutlet weak var categoryLessonNumber: UILabel!
    
    
    func updateViews(for lesson: Int) {
        categoryImage.image = UIImage(named: "LessonIncomplete")
        categoryTitle.text = "Lesson \(lesson)"
        categoryLessonNumber.text = "\(lesson)"
    }
}
