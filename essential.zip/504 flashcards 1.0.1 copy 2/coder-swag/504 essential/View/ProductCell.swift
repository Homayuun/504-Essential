//homayun 2019

import UIKit
import AVFoundation

private(set) public var player: AVAudioPlayer?
var flashCards = [FlashCard]()
class ProductCell: UICollectionViewCell {
    
    @IBOutlet weak var productTitle: UILabel!
    @IBOutlet weak var productPrice: UILabel!
    @IBOutlet weak var exampleEng: UILabel!
    @IBOutlet weak var examplePers: UILabel!
    @IBOutlet weak var flashCardView: UIView!
    @IBOutlet weak var dayCountsLabel: UILabel!
    @IBOutlet weak var mainImg: UIImageView!
    
    
    func updateViews(flashCard: FlashCard) {
        productTitle.text = flashCard.word
        productPrice.text = flashCard.Persian
        exampleEng.text = flashCard.example2
        examplePers.text = flashCard.PersianExampleB
    }
    
    func updateNumber(number: Int){
        dayCountsLabel.text = "\(number)"
    }
    
    override func awakeFromNib() {
        self.layer.applySketchShadow(color: .black, alpha: 0.5, x: 5 , y: 5, blur: 12, spread: 0)
        flashCardView.layer.cornerRadius = 12.0
        mainImg.layer.cornerRadius = 12.0
    }
    
    
}
extension CALayer {
    func applySketchShadow(
        color: UIColor = .black,
        alpha: Float = 0.5,
        x: CGFloat = 0,
        y: CGFloat = 2,
        blur: CGFloat = 4,
        spread: CGFloat = 0)
    {
        shadowColor = color.cgColor
        shadowOpacity = alpha
        shadowOffset = CGSize(width: x, height: y)
        shadowRadius = blur / 2.0
        if spread == 0 {
            shadowPath = nil
        } else {
            let dx = -spread
            let rect = bounds.insetBy(dx: dx, dy: dx)
            shadowPath = UIBezierPath(rect: rect).cgPath
        }
    }
    
    
}
extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}



