//
//  RoundedButton.swift
//  SmackChat
//
//  Created by Homayun on 1/19/1399 AP.
//  Copyright © 1399 AP Homayun. All rights reserved.
//

import UIKit

@IBDesignable
class RoundedButton: UIButton {
    @IBInspectable var cornerRadius: CGFloat = 3.0 {
        didSet{
            self.layer.cornerRadius = cornerRadius
        }
    }
        @IBInspectable var borderWidth: CGFloat = 1.0{
        didSet {
            self.layer.borderWidth = borderWidth
        }
        }
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }

    override func awakeFromNib() {
        self.setupView()
    }
    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()
    }
    func setupView(){
        self.layer.cornerRadius = cornerRadius
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = #colorLiteral(red: 0.3453565705, green: 0.2377169988, blue: 0.4622263642, alpha: 1)
    }
    }
