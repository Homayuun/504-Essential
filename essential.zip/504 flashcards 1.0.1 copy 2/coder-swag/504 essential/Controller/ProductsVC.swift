//
//  ProductsVC.swift
//  parsingJson
//
//  Created by Homayun on 11/28/1400 AP.
//

import UIKit
import AVFoundation

class ProductsVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource ,UITabBarDelegate{
    var indexOfCategory = 0
    var someText = ""
    @IBOutlet weak var quizBtn: UIButton!
    @IBOutlet weak var LessonLabel: UILabel!
    @IBOutlet weak var productsCollection: UICollectionView!
    var product: ProductCell?
    
    let cellScaling: CGFloat = 0.6
    private(set) public var products = [FlashCard]()
    
    func initFlashCards(for category: Int){
        products = DataService.instance.getFlashCards(for: category)
        navigationItem.title = "Lesson: \(category)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LessonLabel.text = "Lesson\(someText)"
        let screenSize = UIScreen.main.bounds.size
        let cellHeight = floor(screenSize.height - (0.3 * screenSize.height) - (quizBtn.bounds.size.height ))
        let cellWidth = floor(screenSize.width - (0.2 * screenSize.width))
        let insetX = (view.bounds.width - cellWidth) / 2.0
        let insetY = (view.bounds.height - cellHeight) / 2.0
        
    let layout = productsCollection!.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        layout.minimumLineSpacing = 80
        productsCollection?.contentInset = UIEdgeInsets(top: insetY, left: insetX, bottom: insetY, right: insetX)
        productsCollection.dataSource = self
        productsCollection.delegate = self
        quizBtn.layer.applySketchShadow(color: #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1), alpha: 0.5, x: 0.5, y: 0.5, blur: 8, spread: 0)
    }
        

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCell", for: indexPath) as? ProductCell {
            let product = products[indexPath.row]
            cell.updateViews(flashCard: product)
            cell.updateNumber(number: indexPath.row + 1)
            cell.isUserInteractionEnabled = true

            return cell
        }
        return ProductCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCell", for: indexPath) as? ProductCell {
            Pronunciation().utterSound(forName: products[indexPath.row].word)
            cell.isUserInteractionEnabled = true
            let flashCard = products[indexPath.row]
            cell.updateViews(flashCard: flashCard)
        }
    }
    
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>)
    {
        let layout = productsCollection?.collectionViewLayout as! UICollectionViewFlowLayout
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        var offset = targetContentOffset.pointee
        let index = (offset.x + scrollView.contentInset.left) / cellWidthIncludingSpacing
        let roundedIndex = round(index)
        
        offset = CGPoint(x: roundedIndex * cellWidthIncludingSpacing - scrollView.contentInset.left, y: -scrollView.contentInset.top)
        targetContentOffset.pointee = offset
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, 0 , 300 , 0)
        cell.layer.transform = rotationTransform
        UIView.animate(withDuration: 1.0){
            cell.layer.transform = CATransform3DIdentity
            cell.layer.applySketchShadow(color: .black, alpha: 0.5, x: 5 , y: 5, blur: 12, spread: 0)
            cell.layer.masksToBounds = false
            cell.layer.cornerRadius = 20
            
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let QuizVC = segue.destination as? QuizVC {
            if segue.identifier == "toQuizVC" {
                
                QuizVC.initQuiz(category: category)
            }
        }

    }
    @IBAction func quizBtnPressed(_ sender: Any) {
        performSegue(withIdentifier: "toQuizVC", sender: quizBtn)
    }
    
}

