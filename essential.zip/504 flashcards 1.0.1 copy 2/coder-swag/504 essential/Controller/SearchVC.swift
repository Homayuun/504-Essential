//
//  SearchVC.swift
//  504 essential words
//
//  Created by Homayun on 12/14/1400 AP.
//  Copyright © 1400 AP Richie_Abenoja. All rights reserved.
//

import UIKit

class SearchVC: UIViewController,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate {
    
    let flashCards = DataService.instance.jsonParsed().flashCards
    var filteredCards =  [FlashCard]()
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        filteredCards = flashCards
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        filteredCards.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "srcCell", for: indexPath) as? SearchCell {
            cell.updateSearhCell(for: filteredCards[indexPath.row])
            return cell
        }
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "srcCell", for: indexPath) as? SearchCell else {return}
        Pronunciation().utterSound(forName: filteredCards[indexPath.row].word)
        cell.updateSearhCell(for: filteredCards[indexPath.row])
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredCards = []
        if searchText == "" {
            filteredCards = flashCards
        }else {
            for card in flashCards {
                if card.word.contains(searchText){
                    filteredCards.append(card)
                }
            }
            tableView.reloadData()
            
        }
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
        {
            searchBar.resignFirstResponder()
            searchBar.endEditing(true)
        }


}
