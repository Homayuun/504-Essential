//
//  FlashCards.swift
//  parsingJson
//
//  Created by Homayun on 11/28/1400 AP.
//


import Foundation

struct FlashCards: Codable {
    private(set) public var flashCards: [FlashCard]
}

struct FlashCard: Codable {
    private(set) public var word: String
    private(set) public var Persian: String
    private(set) public var lesson: Int
    private(set) public var example2: String
    private(set) public var PersianExampleB: String
}
