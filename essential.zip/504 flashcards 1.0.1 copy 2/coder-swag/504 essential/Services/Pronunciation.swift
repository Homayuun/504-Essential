//
//  Pronunciation.swift
//  504 essential words
//
//  Created by Homayun on 12/14/1400 AP.
//  Copyright © 1400 AP Richie_Abenoja. All rights reserved.
//

import Foundation
import AVFoundation

struct Pronunciation {
    
        func utterSound(forName : String){
        let utterance = AVSpeechUtterance(string: forName)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
        
    }
}
