//
//  QuizVC.swift
//  504 essential words
//
//  Created by Homayun on 4/31/1399 AP.
//  Copyright © 1399 AP Richie_Abenoja. All rights reserved.
//

import UIKit

class QuizVC: UIViewController {

    var products = [FlashCard]()
    
    var currentQuestion = 0
    var rightAnswerPlacement:UInt32 = 0
    var wrongAnswerPlacements: [UInt32] = []
    
    var points = 0;
    
    @IBOutlet weak var quizQuestionLbl: UILabel!
    @IBOutlet var options: [RoundedButton]!
    
    
    func initQuiz(category: Int) {
        products = DataService.instance.getFlashCards(for: category)
        navigationItem.title = "Lesson \(category)"
    }
    
    
    func setupQA(){
    }
    @IBAction func optionPressed(_ sender: AnyObject) {
        let Lesson1questionList: [String] = DataService.instance.getFlashCards(for:category).map{$0.word}
        
        if (sender.tag == Int(rightAnswerPlacement))
        {
            print ("RIGHT!")
            points += 1
        }
        else
        {
            print ("WRONG!!!!!!")
        }
        
        if ( currentQuestion != Lesson1questionList.count)
        {
            
            newQuestion()
            
        }
        else
        {
            performSegue(withIdentifier: "toCategories", sender: self)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newQuestion()
    }
        func newQuestion()
    {
        let Lesson1questionList: [String] = DataService.instance.getFlashCards(for:category).map{$0.word}
        
        let lesson1answerList: [String] = DataService.instance.getFlashCards(for: category).map{$0.Persian}
        
        rightAnswerPlacement = arc4random_uniform(4)+1
        
        //Create a button
        var button: UIButton = UIButton()
        for i in 1...4
        {
            button = view.viewWithTag(i) as! UIButton
            
            quizQuestionLbl.text = Lesson1questionList[currentQuestion]
            
            let rightAnswer = lesson1answerList[currentQuestion]
            var wrongAnswers = DataService.instance.jsonParsed().flashCards.map{$0.Persian}.filter { answer in
                answer != rightAnswer
            }
            let wrongAnswerIndex = wrongAnswers.indices.randomElement()!

            if (i == Int(rightAnswerPlacement))
            {
                button.setTitle(rightAnswer, for: .normal)
                
            }
            else
            {
                button.setTitle(wrongAnswers[wrongAnswerIndex], for: .normal)
                wrongAnswers.remove(at: wrongAnswerIndex)
                
            }
            
            
            
        }
        currentQuestion += 1
        
        
    }
}
