//
//  DataService.swift
//  parsingJson
//
//  Created by Homayun on 11/28/1400 AP.
//

import Foundation

class DataService {
    static let instance = DataService()
    
    
    func jsonParsed() -> FlashCards{
        let url = Bundle.main.url(forResource: "words", withExtension: "json")
        let decoder = JSONDecoder()
        var json: FlashCards?
        do{
            let jsonFile = try Data(contentsOf: url!)
            json = try decoder.decode(FlashCards.self, from: jsonFile)
            

            
                        
        }catch{
            print(error)
        }
        return json!
    }
    func getFlashCards(for number: Int) -> [FlashCard]{
        
        var dict = [FlashCard]()
        
        for i in jsonParsed().flashCards{
            let word = i.word
            let Persian = i.Persian
            let lessonNumber = i.lesson
            let exampleEng = i.example2
            let examplePer = i.PersianExampleB
            if lessonNumber == number {
                let dictc = [FlashCard(word: word, Persian: Persian, lesson: lessonNumber , example2: exampleEng, PersianExampleB: examplePer)]
                dict.append(contentsOf: dictc)
            }
        }
            return dict
    }
    func getLessonList() -> [Int]{
        let numbersCopy = jsonParsed().flashCards.map{$0.lesson}
        let lessonNumbers = numbersCopy.removingDuplicates()
        return lessonNumbers
    }
 
}


//Extension

extension Array where Element: Hashable {
    func removingDuplicates() -> [Element] {
        var addedDict = [Element: Bool]()

        return filter {
            addedDict.updateValue(true, forKey: $0) == nil
        }
    }

    mutating func removeDuplicates() {
        self = self.removingDuplicates()
    }
}

