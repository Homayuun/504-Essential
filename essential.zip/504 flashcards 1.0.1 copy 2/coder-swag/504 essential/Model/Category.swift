//
//  Category.swift
//  parsingJson
//
//  Created by Homayun on 11/28/1400 AP.
//

import Foundation


struct Category {
    private(set) public var word: String
    private(set) public var lessonNumber: Int
    
    init(title: String ,lessonNumber: Int) {
        self.word = title
        self.lessonNumber = lessonNumber
    }
}
