//
//  SearchCell.swift
//  504 essential words
//
//  Created by Homayun on 12/14/1400 AP.
//  Copyright © 1400 AP Richie_Abenoja. All rights reserved.
//

import UIKit

class SearchCell: UITableViewCell {

    @IBOutlet weak var wordEnLbl: UILabel!
    @IBOutlet weak var wordFaLbl: UILabel!
    @IBOutlet weak var exampleEnLbl: UILabel!
    @IBOutlet weak var exampleFaLbl: UILabel!
    
    func updateSearhCell(for flashCard: FlashCard) {
        wordEnLbl.text = flashCard.word
        wordFaLbl.text = flashCard.Persian
        exampleEnLbl.text = flashCard.example2
        exampleFaLbl.text = flashCard.PersianExampleB
    }


}
